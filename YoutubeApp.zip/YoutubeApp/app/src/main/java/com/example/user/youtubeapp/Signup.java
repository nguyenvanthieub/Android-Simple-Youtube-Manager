package com.example.user.youtubeapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class Signup extends AppCompatActivity {
    private WebView signUp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        signUp = (WebView)findViewById(R.id.signup);
        WebSettings webSettings = signUp.getSettings();
        webSettings.setJavaScriptEnabled(true);
        signUp.loadUrl("https://accounts.google.com/ServiceLogin?passive=true&continue=https%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26next%3D%252F%26hl%3Dvi%26feature%3Dsign_in_button&service=youtube&hl=vi&uilel=3#identifier");
        onBackPressed();
    }
    @Override
    public void onBackPressed() {
        if (signUp.canGoBack()) {
            signUp.goBack();
            return;
        }

        // Otherwise defer to system default behavior.
        super.onBackPressed();
    }
}
