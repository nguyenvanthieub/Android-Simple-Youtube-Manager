package com.example.user.youtubeapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class Youtube extends AppCompatActivity {
    private WebView youtube_open;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_youtube);
        youtube_open = (WebView)findViewById(R.id.you_tub);
        WebSettings webSettings = youtube_open.getSettings();
        webSettings.setJavaScriptEnabled(true);
        youtube_open.loadUrl("https://www.youtube.com");
        onBackPressed();
    }

    @Override
    public void onBackPressed() {
        if (youtube_open.canGoBack()) {
            youtube_open.goBack();
            return;
        }

        // Otherwise defer to system default behavior.
        super.onBackPressed();
    }
}
