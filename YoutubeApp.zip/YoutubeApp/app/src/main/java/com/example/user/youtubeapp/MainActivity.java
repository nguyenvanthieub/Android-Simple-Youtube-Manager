package com.example.user.youtubeapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button open_youtube;
    private Button my_history;
    private Button sign_up;
    private Button sign_in;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        openYoutube();
        openHistory();
        openSignUp();
        openSignIn();
    }

    //open youtube
    public void openYoutube(){
        open_youtube = (Button)findViewById(R.id.button);
        open_youtube.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent youtubeIntent = new Intent("com.example.user.youtubeapp.Youtube");
                        startActivity(youtubeIntent);
                    }
                }
        );
    }

    //open history
    public void openHistory(){
        my_history = (Button)findViewById(R.id.button2);
        my_history.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent historyIntent = new Intent("com.example.user.youtubeapp.History");
                        startActivity(historyIntent);
                    }
                }
        );
    }

    //open sign up
    public void openSignUp(){
        sign_up = (Button)findViewById(R.id.button3);
        sign_up.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent signUpIntent = new Intent("com.example.user.youtubeapp.Signup");
                        startActivity(signUpIntent);
                    }
                }
        );
    }

    //open sign in
    public void openSignIn(){
        sign_in = (Button)findViewById(R.id.button4);
        sign_in.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent signInIntent = new Intent("com.example.user.youtubeapp.Signin");
                        startActivity(signInIntent);
                    }
                }
        );
    }
}
