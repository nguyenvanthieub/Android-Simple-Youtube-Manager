package com.example.user.youtubeapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class Signin extends AppCompatActivity {
    private WebView signIn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);
        signIn =(WebView)findViewById(R.id.signin);
        WebSettings webSettings = signIn.getSettings();
        webSettings.setJavaScriptEnabled(true);
        signIn.loadUrl("https://accounts.google.com/AddSession?passive=false&continue=http%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26next%3D%252Fwatch%253Fv%253Dbrwl3bjvyf8%2526index%253D11%2526list%253DPL8SxI9D79jM7MaRey9MY5b4CdEqWdrx2V%26hl%3Den&service=youtube&uilel=0&hl=en#identifier");
        onBackPressed();
    }
    @Override
    public void onBackPressed() {
        if (signIn.canGoBack()) {
            signIn.goBack();
            return;
        }

        // Otherwise defer to system default behavior.
        super.onBackPressed();
    }
}
