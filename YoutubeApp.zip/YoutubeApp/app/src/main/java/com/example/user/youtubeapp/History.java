package com.example.user.youtubeapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class History extends AppCompatActivity {
    private WebView history_view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        history_view =(WebView)findViewById(R.id.history);
        WebSettings webSettings = history_view.getSettings();
        webSettings.setJavaScriptEnabled(true);
        history_view.loadUrl("https://www.youtube.com/feed/history");
        onBackPressed();
    }
    @Override
    public void onBackPressed() {
        if (history_view.canGoBack()) {
            history_view.goBack();
            return;
        }

        // Otherwise defer to system default behavior.
        super.onBackPressed();
    }
}
